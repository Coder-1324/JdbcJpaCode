package com.example.jpa;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ApplicationContext;

import com.example.jpa.dao.UserRepository;
import com.example.jpa.entities.User;

@SpringBootApplication
public class JpaTestApplication {

	public static void main(String[] args) {
		ApplicationContext context =SpringApplication.run(JpaTestApplication.class, args);
		
		UserRepository userRepository = context.getBean(UserRepository.class);
		
		User user  = new User();
		
		user.setName("Nikhil Chopde");
		user.setCity("Pune");
		user.setStatus("java programmer");
		
		User user1 =userRepository.save(user);
		
	}

}
