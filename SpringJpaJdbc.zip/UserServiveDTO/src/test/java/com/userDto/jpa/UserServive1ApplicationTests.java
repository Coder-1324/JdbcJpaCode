package com.userDto.jpa;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class UserServive1ApplicationTests {

	@Test
	void contextLoads() {
	}

}
