package com.userDto.jpa;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class UserServive1Application {

	public static void main(String[] args) {
		SpringApplication.run(UserServive1Application.class, args);
	}

}
