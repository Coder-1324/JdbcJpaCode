package com.userDto.jpa.repo;

import org.springframework.data.jpa.repository.JpaRepository;

import com.userDto.jpa.dao.User;

public interface UserRepository extends JpaRepository<User, Long> {
}