package com.userservive.jpa.repo;

import org.springframework.data.jpa.repository.JpaRepository;

import com.userservive.jpa.usr.User;

public interface UserRepository extends JpaRepository<User, Long> {
}