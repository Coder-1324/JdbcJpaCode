package com.userservive.jpa;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class UserServiveApplication {

	public static void main(String[] args) {
		SpringApplication.run(UserServiveApplication.class, args);
	}

}
