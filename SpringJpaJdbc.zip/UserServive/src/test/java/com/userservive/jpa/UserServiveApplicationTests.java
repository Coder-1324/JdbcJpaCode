package com.userservive.jpa;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class UserServiveApplicationTests {

	@Test
	void contextLoads() {
	}

}
